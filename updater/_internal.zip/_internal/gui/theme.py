# Zapret Launcher - Bypass restrictions
# Copyright (C) 2026 avaxngard corp
#
# This is free software: you can redistribute it and/or modify it
# under the terms of the GNU GPL v3 or any later version.
#
# Distributed WITHOUT ANY WARRANTY.

from utils.languages import tr

def get_theme(theme_name='Dark'):
    themes = {
        'Dark': {
            'accent': '#6c5579',
            'accent_hover': '#e8ccf7',
            'accent_green': '#4ade80',
            'accent_darkgreen': '#348f55',
            'accent_red': '#EF4444',
            
            'bg_dark': '#0F0F12',
            'bg_medium': '#1A1A1F',
            'bg_light': '#25252B',
            'bg_light_hover': '#3a3a44',
            
            'text_primary': '#FFFFFF',
            'text_select': '#FFFFFF',
            'text_secondary': '#A1A1AA',
            
            'button_bg': '#2D2D35',
            'button_hover': '#3D3D45',
            'button_text': '#FFFFFF',
            'button_text_hover': '#FFFFFF',
            
            'separator': "#2D2D35"
        },
        'Pink': {
            'accent': "#D4438C",
            'accent_hover': "#DD72A9",
            'accent_green': '#4ade80',
            'accent_darkgreen': '#348f55',
            'accent_red': '#EF4444',
            
            'bg_dark': '#1E1B2E',
            'bg_medium': '#2D2A3F',
            'bg_light': '#3D3A55',
            'bg_light_hover': '#4D4A6B',
            
            'text_primary': '#FFFFFF',
            'text_select': '#FFFFFF',
            'text_secondary': "#B0B0C9",
            
            'button_bg': '#4D4A6B',
            'button_hover': '#5D5A7B',
            'button_text': '#FFFFFF',
            'button_text_hover': '#FFFFFF',
            
            'separator': "#46435A"
        },
        'Old': {
            'accent': "#3B82F6",
            'accent_hover': "#60A5FA",
            'accent_green': '#4ade80',
            'accent_darkgreen': '#348f55',
            'accent_red': '#EF4444',
            
            'bg_dark': '#0F172A',
            'bg_medium': '#1E293B',
            'bg_light': '#334155',
            'bg_light_hover': '#475569',
            
            'text_primary': '#FFFFFF',
            'text_select': '#FFFFFF',
            'text_secondary': "#94A3B8",
            
            'button_bg': '#475569',
            'button_hover': '#64748B',
            'button_text': '#FFFFFF',
            'button_text_hover': '#FFFFFF',
            
            'separator': "#3E4C63"
        },
        'Sakura': {
            'accent': "#E09BA9",
            'accent_hover': "#E4B4BF",
            'accent_green': '#4ade80',
            'accent_darkgreen': '#348f55',
            'accent_red': '#EF4444',
                    
            'bg_dark': '#1F1519',
            'bg_medium': '#2B1D22',
            'bg_light': '#3D2A32',
            'bg_light_hover': '#4F3842',
                    
            'text_primary': '#FDF5F7',
            'text_select': '#FFFFFF',
            'text_secondary': '#D4B5C0',
                    
            'button_bg': '#4F3842',
            'button_hover': '#6B4D5B',
            'button_text': '#FDF5F7',
            'button_text_hover': '#FFFFFF',
                    
            'separator': '#4F3842'
        },
        'Light': {
            'accent': '#7c5a8a',
            'accent_hover': '#9b78a8',
            'accent_green': '#059669',
            'accent_darkgreen': '#047857',
            'accent_red': '#DC2626',
            
            'bg_dark': '#F0F0F2',
            'bg_medium': '#E4E4E8',
            'bg_light': '#FFFFFF',
            'bg_light_hover': '#DADAE0',
            
            'text_primary': '#1A1A1F',
            'text_select': '#1A1A1F',
            'text_secondary': '#5A5A66',
            
            'button_bg': "#D3D0D0",
            'button_hover': '#E8E8EE',
            'button_text': '#1A1A1F',
            'button_text_hover': '#FFFFFF',
            
            'separator': '#D0D0D8'
        },
        'Orange': {
            'accent': '#E87A1E',
            'accent_hover': '#FF9A3C',
            'accent_green': '#8BC34A',
            'accent_darkgreen': '#5B8A2A',
            'accent_red': '#C1362F',

            'bg_dark': '#1A120B',
            'bg_medium': '#241812',
            'bg_light': '#3A2618',
            'bg_light_hover': '#503522',

            'text_primary': '#F4E4C1',
            'text_select': '#FFFFFF',
            'text_secondary': '#B89968',

            'button_bg': "#533723",
            'button_hover': '#503522',
            'button_text': '#F4E4C1',
            'button_text_hover': '#FFFFFF',

            'separator': '#4A3020'
        },
        'Contrast': {
            'accent': '#000000',
            'accent_hover': '#333333',
            'accent_green': '#059669',
            'accent_darkgreen': '#047857',
            'accent_red': '#DC2626',

            'bg_dark': '#FFFFFF',
            'bg_medium': "#BBB7B7",
            'bg_light': "#DAD8D8",
            'bg_light_hover': "#D8D4D4",

            'text_primary': '#000000',
            'text_select': '#FFFFFF',
            'text_secondary': '#404040',

            'button_bg': '#000000',
            'button_hover': '#333333',
            'button_text': '#FFFFFF',
            'button_text_hover': '#FFFFFF',

            'separator': '#808080'
        }
    }
    return themes.get(theme_name, themes['Dark'])

def get_theme_names():
    return ['Dark', 'Pink', 'Old', 'Sakura', 'Light', 'Orange', 'Contrast']

def get_theme_display_name(theme_name: str) -> str:
    key = f"theme_{theme_name.lower()}"
    translated = tr(key)
    if translated == key:
        return theme_name
    return translated
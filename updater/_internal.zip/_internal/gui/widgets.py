# Zapret Launcher - Bypass restrictions
# Copyright (C) 2026 avaxngard corp
#
# This is free software: you can redistribute it and/or modify it
# under the terms of the GNU GPL v3 or any later version.
#
# Distributed WITHOUT ANY WARRANTY.

import tkinter as tk
import traceback
from config import APPDATA_DIR
from datetime import datetime

def _log_widget(msg: str):
    try:
        log_file = APPDATA_DIR / "logs.txt"
        ts = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{ts}] [widgets] {msg}\n")
    except Exception:
        pass

def _get_parent_bg(parent):
    try:
        if hasattr(parent, 'cget'):
            return parent.cget('bg')
        elif isinstance(parent, tk.Tk):
            return parent.cget('bg')
        else:
            return '#2b2b2b'
    except (tk.TclError, AttributeError):
        return '#2b2b2b'

class ModernSwitch(tk.Canvas):
    def __init__(self, parent, width=50, height=24, bg_color='#25252B', active_color='#4361ee', command=None, initial=False):
        super().__init__(parent, width=width, height=height, highlightthickness=0, bg=parent.cget('bg') if hasattr(parent, 'cget') else '#2b2b2b')
        self.active_color = active_color
        self.inactive_color = bg_color
        self.state = initial
        self.command = command
        self.width = width
        self.height = height
        
        self.bg_rect = self.create_oval(2, 2, width-2, height-2, fill=self.inactive_color, outline='#2D2D35', width=1)
        self.slider = self.create_oval(4, 4, height-4, height-4, fill='#ffffff', outline='', tags=('slider',))
        
        if self.state:
            self.coords(self.slider, width-height+4, 4, width-4, height-4)
            self.itemconfig(self.bg_rect, fill=self.active_color)
        
        self.tag_bind(self.bg_rect, "<Button-1>", self.on_click)
        self.tag_bind("slider", "<Button-1>", self.on_click)

    def on_click(self, event):
        self.state = not self.state
        try:
            if self.state:
                self.coords(self.slider, self.width-self.height+4, 4, self.width-4, self.height-4)
                self.itemconfig(self.bg_rect, fill=self.active_color)
            else:
                self.coords(self.slider, 4, 4, self.height-4, self.height-4)
                self.itemconfig(self.bg_rect, fill=self.inactive_color)
        except Exception as e:
            _log_widget(f"ModernSwitch.on_click draw error: {e}")

        if self.command:
            try:
                self.command(self.state)
            except Exception as e:
                _log_widget(
                    f"ModernSwitch command error (state={self.state}): {e}\n"
                    f"{traceback.format_exc()}"
                )

class RoundedButton(tk.Canvas):
    def __init__(self, parent, text, command, width=200, height=40, 
            bg='#2D2D35', fg='#FFFFFF',
            font=("Inter", 11, "bold"), 
            corner_radius=8, hover_color=None, hover_fg='#FFFFFF',
            animation_steps=5, theme_name='Dark'):
        super().__init__(parent, width=width, height=height, highlightthickness=0, bg=_get_parent_bg(parent), cursor="hand2")
        
        if hover_color is None:
            if theme_name == 'Dark':
                self.hover_color = '#9b78a8'
            elif theme_name == 'Pink':
                self.hover_color = '#DD72A9'
            elif theme_name == 'Old':
                self.hover_color = '#60A5FA'
            elif theme_name == 'Halloween':
                self.hover_color = '#FF9A3C'
            elif theme_name == 'Contrast':
                self.hover_color = '#333333'
            else:
                self.hover_color = '#9b78a8'

        self._command = command
        self.command = command
        self.bg = bg
        self.normal_fg = fg
        self.hover_fg = hover_fg
        self.fg = fg
        self.font = font
        self.enabled = True
        self.normal_color = bg
        self.hover_color = hover_color
        self.corner_radius = corner_radius
        self._text = text
        self._animating = False
        self._is_animating = False
        self._animation_id = None
        self.animation_steps = animation_steps
        self.theme_name = theme_name
        
        self.original_width = width
        self.original_height = height
        self.original_x = 0
        self.original_y = 0
        
        points = []
        points.extend([corner_radius, 0, width-corner_radius, 0])
        points.extend([width, 0, width, corner_radius, width, height-corner_radius, width, height])
        points.extend([width-corner_radius, height, corner_radius, height])
        points.extend([0, height, 0, height-corner_radius, 0, corner_radius, 0, 0])
        self.rect = self.create_polygon(points, smooth=True, fill=bg, outline='')
        self.text_id = self.create_text(width//2, height//2, text=text, fill=fg, font=font)
        
        for item in [self.rect, self.text_id]:
            self.tag_bind(item, "<Button-1>", self.on_click)
            self.tag_bind(item, "<Enter>", self.on_enter)
            self.tag_bind(item, "<Leave>", self.on_leave)

    def on_click(self, event):
        if not self.enabled:
            return
        
        if not self._command:
            return
        
        if hasattr(self, '_is_animating') and self._is_animating:
            return
        
        self._is_animating = True
        cmd = self._command
        
        self._animate_press(step=0)
        self.after(120, lambda: self._animate_release(step=0))
        self.after(150, lambda: self._execute_command(cmd))

    def _execute_command(self, cmd):
        self._is_animating = False
        if cmd and self.enabled:
            try:
                cmd()
            except Exception as e:
                _log_widget(f"RoundedButton command error: {e}\n{traceback.format_exc()}")

    def _animate_press(self, step):
        if step >= self.animation_steps:
            return
        
        progress = 1 - (step / self.animation_steps) * 0.05
        new_width = max(20, int(self.original_width * progress))
        new_height = max(20, int(self.original_height * progress))
        x_offset = (self.original_width - new_width) // 2
        y_offset = (self.original_height - new_height) // 2
        
        corner = min(self.corner_radius, new_width // 2, new_height // 2)
        
        self.config(width=new_width, height=new_height)
        
        points = []
        points.extend([corner, 0, new_width - corner, 0])
        points.extend([new_width, 0, new_width, corner, new_width, new_height - corner, new_width, new_height])
        points.extend([new_width - corner, new_height, corner, new_height])
        points.extend([0, new_height, 0, new_height - corner, 0, corner, 0, 0])
        
        self.coords(self.rect, points)
        self.coords(self.text_id, new_width//2, new_height//2)
        
        self._animation_id = self.after(15, lambda: self._animate_press(step + 1))

    def _animate_release(self, step):
        if step >= self.animation_steps:
            self.config(width=self.original_width, height=self.original_height)
            self.coords(self.text_id, self.original_width//2, self.original_height//2)
            self._update_rect_coords()
            return
        
        progress = 1 - ((self.animation_steps - step - 1) / self.animation_steps) * 0.05
        new_width = int(self.original_width * progress)
        new_height = int(self.original_height * progress)
        x_offset = (self.original_width - new_width) // 2
        y_offset = (self.original_height - new_height) // 2
        
        self.config(width=new_width, height=new_height)
        
        points = []
        points.extend([self.corner_radius - x_offset, y_offset, 
                    new_width - self.corner_radius + x_offset, y_offset])
        points.extend([new_width - x_offset, y_offset, 
                    new_width - x_offset, self.corner_radius + y_offset, 
                    new_width - x_offset, new_height - self.corner_radius + y_offset, 
                    new_width - x_offset, new_height - y_offset])
        points.extend([new_width - self.corner_radius + x_offset, new_height - y_offset, 
                      self.corner_radius - x_offset, new_height - y_offset])
        points.extend([x_offset, new_height - y_offset, 
                    x_offset, new_height - self.corner_radius + y_offset, 
                    x_offset, self.corner_radius + y_offset, 
                    x_offset, y_offset])
        
        self.coords(self.rect, points)
        self.coords(self.text_id, new_width//2, new_height//2)
        self._animation_id = self.after(15, lambda: self._animate_release(step + 1))

    def _update_rect_coords(self):
        points = []
        points.extend([self.corner_radius, 0, self.original_width - self.corner_radius, 0])
        points.extend([self.original_width, 0, self.original_width, self.corner_radius, 
                    self.original_width, self.original_height - self.corner_radius, 
                    self.original_width, self.original_height])
        points.extend([self.original_width - self.corner_radius, self.original_height, 
                      self.corner_radius, self.original_height])
        points.extend([0, self.original_height, 0, self.original_height - self.corner_radius, 
                    0, self.corner_radius, 0, 0])
        self.coords(self.rect, points)

    def on_enter(self, event):
        if self.enabled:
            self.itemconfig(self.rect, fill=self.hover_color)
            self.itemconfig(self.text_id, fill=self.hover_fg)

    def on_leave(self, event):
        if self.enabled:
            self.itemconfig(self.rect, fill=self.normal_color)
            self.itemconfig(self.text_id, fill=self.normal_fg)

    def set_text(self, text):
        self._text = text
        self.itemconfig(self.text_id, text=text)

    def get_text(self):
        return self._text

    def set_enabled(self, enabled):
        self.enabled = enabled
        color = self.normal_color if enabled else '#666666'
        self.itemconfig(self.rect, fill=color)
        self.itemconfig(self.text_id, fill=self.normal_fg if enabled else '#A0A0A0')

    def update_colors(self, bg_color, fg_color, hover_color):
        self.normal_color = bg_color
        self.hover_color = hover_color
        self.normal_fg = fg_color
        self.itemconfig(self.rect, fill=bg_color)
        self.itemconfig(self.text_id, fill=fg_color)

    def update_theme(self, theme_name):
            self.theme_name = theme_name
            
            if theme_name == 'Dark':
                self.hover_color = '#9b78a8'
            elif theme_name == 'Pink':
                self.hover_color = '#DD72A9'
            elif theme_name == 'Old':
                self.hover_color = '#60A5FA'
            elif theme_name == 'Halloween':
                self.hover_color = '#FF9A3C'
            elif theme_name == 'Contrast':
                self.hover_color = '#333333'
            else:
                self.hover_color = '#9b78a8'
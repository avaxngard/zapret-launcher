# Zapret Launcher - Bypass restrictions
# Copyright (C) 2026 avaxngard corp
#
# This is free software: you can redistribute it and/or modify it
# under the terms of the GNU GPL v3 or any later version.
#
# Distributed WITHOUT ANY WARRANTY.

import tkinter as tk
from utils.scaling import scale_size, scale_font
from utils.languages import tr, tr_plural
from utils.messagebox import messagebox
from config import STATS_RETRY_INTERVAL_MS

MODE_TRANSLATION_KEYS = {
    "Standard": "mode_standard",
    "Combined": "mode_zapret_tgproxy"
}

class StatsPage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=app.colors["bg_dark"])
        self.app = app
        self.colors = app.colors
        self.sf = app.scale_factor
        self._labels = {}

        self._retry_timer_id = None
        self._stats_loaded = False
        self._destroyed = False

        self._build()
        self._load_stats()

    def get_frame(self):
        return self

    def _build(self):
        c = self.colors
        sf = self.sf

        padx = scale_size(30, sf)
        pady = scale_size(20, sf)

        header_frame = tk.Frame(self, bg=c["bg_dark"])
        header_frame.pack(fill=tk.X, padx=padx, pady=(scale_size(30, sf), 5))

        tk.Label(
            header_frame,
            text=tr("stats_title"),
            font=("Inter", scale_size(20, sf), "bold"),
            fg=c["text_primary"], bg=c["bg_dark"]
        ).pack(anchor="w")

        tk.Label(
            header_frame,
            text=tr("stats_desc"),
            font=("Inter", scale_size(10, sf)),
            fg=c["text_secondary"], bg=c["bg_dark"]
        ).pack(anchor="w", pady=(5, 0))

        outer = tk.Frame(self, bg=c["bg_dark"])
        outer.pack(fill=tk.BOTH, expand=True, padx=padx, pady=pady)

        hero = tk.Frame(outer, bg=c["bg_medium"], height=scale_size(140, sf))
        hero.pack(fill=tk.X)
        hero.pack_propagate(False)

        tk.Frame(hero, bg=c["accent"], width=scale_size(4, sf)).place(x=0, y=0, relheight=1.0)

        hero_inner = tk.Frame(hero, bg=c["bg_medium"])
        hero_inner.place(x=scale_size(32, sf), rely=0.5, anchor="w")

        tk.Label(
            hero_inner,
            text=tr("stats_since_upper"),
            font=("Inter", scale_size(10, sf)),
            fg=c["text_secondary"], bg=c["bg_medium"]
        ).pack(anchor="w")

        self._labels["first_connect"] = tk.Label(
            hero_inner,
            text="—",
            font=("Inter", scale_size(26, sf), "bold"),
            fg=c["text_primary"], bg=c["bg_medium"]
        )
        self._labels["first_connect"].pack(anchor="w", pady=(scale_size(4, sf), 0))

        self._labels["hero_sub"] = tk.Label(
            hero_inner,
            text="—",
            font=("Inter", scale_size(10, sf)),
            fg=c["text_secondary"], bg=c["bg_medium"]
        )
        self._labels["hero_sub"].pack(anchor="w", pady=(scale_size(6, sf), 0))

        id_frame = tk.Frame(outer, bg=c["bg_dark"])
        id_frame.pack(fill=tk.X, pady=(scale_size(12, sf), 0))

        self._id_link = tk.Label(
            id_frame,
            text=tr("stats_your_install_id"),
            font=("Inter", scale_size(10, sf)),
            fg=c["accent"],
            bg=c["bg_dark"],
            cursor="hand2"
        )
        self._id_link.pack(anchor="w")

        self._id_link.bind("<Enter>", lambda e: self._id_link.config(fg=c["accent_hover"]))
        self._id_link.bind("<Leave>", lambda e: self._id_link.config(fg=c["accent"]))
        self._id_link.bind("<Button-1>", self._on_install_id_click)

        grid = tk.Frame(outer, bg=c["bg_dark"])
        grid.pack(fill=tk.X, pady=(scale_size(20, sf), 0))

        for i in range(4):
            grid.columnconfigure(i, weight=1, uniform="stats")

        self._labels["total_sessions"] = self._make_card(
            grid, tr("stats_sessions_total"), "—", "—", "accent", col=0
        )
        self._labels["last_session"] = self._make_card(
            grid, tr("stats_longest"), "—", "—", "default", col=1
        )
        self._labels["fav_mode"] = self._make_card(
            grid, tr("stats_fav_mode"), "—", "—", "accent", col=2
        )
        self._labels["current_strategy"] = self._make_card(
            grid, tr("stats_ping"), "—", "—", "duo", col=3
        )

    def _make_card(self, parent, label, value, sub, vtype, col):
        c = self.colors
        sf = self.sf
        SOF = 0.2 

        card = tk.Frame(
            parent, bg=c["bg_medium"],
            highlightthickness=1, highlightbackground=c["separator"],
        )
        card.configure(padx=scale_size(20, sf), pady=scale_size(18, sf))
        card.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else scale_size(8, sf), 0))

        tk.Label(
            card, text=label.upper(),
            font=("Inter", scale_font(9, sf, softness=SOF)),
            fg=c["text_secondary"], bg=c["bg_medium"], anchor="w"
        ).pack(fill=tk.X)

        if vtype == "duo":
            row = tk.Frame(card, bg=c["bg_medium"])
            row.pack(fill=tk.X, anchor="w", pady=(scale_size(10, sf), 0))

            v1 = tk.Label(row, text=value,
                          font=("Inter", scale_font(18, sf, softness=SOF), "bold"),
                          fg=c["accent"], bg=c["bg_medium"])
            v1.pack(side=tk.LEFT)

            tk.Label(row, text="/",
                     font=("Inter", scale_font(16, sf, softness=SOF)),
                     fg=c["text_secondary"], bg=c["bg_medium"]
                     ).pack(side=tk.LEFT, padx=scale_size(6, sf))

            v2 = tk.Label(row, text="—",
                          font=("Inter", scale_font(18, sf, softness=SOF), "bold"),
                          fg=c["accent"], bg=c["bg_medium"])
            v2.pack(side=tk.LEFT)

            value_label = (v1, v2)
        else:
            color = c["accent"] if vtype == "accent" else c["accent"]
            
            value_label = tk.Label(
                card, text=value,
                font=("Inter", scale_font(18, sf, softness=SOF), "bold"),
                fg=color, bg=c["bg_medium"], anchor="w"
            )
            value_label.pack(fill=tk.X, pady=(scale_size(10, sf), 0))

        sub_label = tk.Label(
            card, text=sub,
            font=("Inter", scale_size(9, sf)),
            fg=c["text_secondary"], bg=c["bg_medium"], anchor="w"
        )
        sub_label.pack(fill=tk.X, pady=(scale_size(8, sf), 0))
        return {"value": value_label, "sub": sub_label}

    def _has_stats(self) -> bool:
        user_stats = getattr(self.app, "user_stats", None)
        return bool(user_stats and getattr(user_stats, "cached_stats", None))

    def _load_stats(self):
        user_stats = getattr(self.app, "user_stats", None)
        if user_stats is None:
            return

        if self._has_stats():
            self._apply_stats(user_stats.cached_stats)
            self._stats_loaded = True
            return

        self._wait_for_cache(attempts=20)

    def _wait_for_cache(self, attempts):
        if self._destroyed or self._stats_loaded:
            return

        user_stats = getattr(self.app, "user_stats", None)
        if user_stats and getattr(user_stats, "cached_stats", None):
            self._apply_stats(user_stats.cached_stats)
            self._stats_loaded = True
            self._cancel_retry_timer()
            return

        if attempts > 0:
            self.after(250, lambda: self._wait_for_cache(attempts - 1))
        else:
            self._schedule_stats_retry()

    def _schedule_stats_retry(self):
        if self._destroyed or self._stats_loaded:
            return

        self._cancel_retry_timer()
        try:
            self._retry_timer_id = self.after(STATS_RETRY_INTERVAL_MS, self._retry_load_stats)
        except Exception:
            self._retry_timer_id = None

    def _retry_load_stats(self):
        self._retry_timer_id = None

        if self._destroyed or self._stats_loaded:
            return

        user_stats = getattr(self.app, "user_stats", None)
        if user_stats is None:
            self._schedule_stats_retry()
            return

        if getattr(user_stats, "cached_stats", None):
            self._apply_stats(user_stats.cached_stats)
            self._stats_loaded = True
            self._cancel_retry_timer()
            return

        try:
            user_stats.fetch_user_stats()
        except Exception:
            pass

        self._wait_for_cache_after_fetch(attempts=60)

    def _wait_for_cache_after_fetch(self, attempts):
        if self._destroyed or self._stats_loaded:
            return

        user_stats = getattr(self.app, "user_stats", None)
        if user_stats and getattr(user_stats, "cached_stats", None):
            self._apply_stats(user_stats.cached_stats)
            self._stats_loaded = True
            self._cancel_retry_timer()
            return

        if attempts > 0:
            self.after(250, lambda: self._wait_for_cache_after_fetch(attempts - 1))
        else:
            self._schedule_stats_retry()

    def _cancel_retry_timer(self):
        if self._retry_timer_id is not None:
            try:
                self.after_cancel(self._retry_timer_id)
            except Exception:
                pass
            self._retry_timer_id = None

    def _apply_stats(self, stats):
        if not stats:
            return

        days = stats.get("days_since", 0)
        total = stats.get("total_sessions", 0)
        self._labels["first_connect"].config(text=stats.get("created_at", "—"))

        days_word = tr_plural(
            days,
            "stats_days_word_one",
            "stats_days_word_few",
            "stats_days_word_many"
        ).split(" ", 1)[-1]

        sessions_word = tr_plural(
            total,
            "stats_sessions_word_one",
            "stats_sessions_word_few",
            "stats_sessions_word_many"
        ).split(" ", 1)[-1]

        self._labels["hero_sub"].config(
            text=tr(
                "stats_since_days",
                days=days,
                days_word=days_word,
                total=total,
                sessions_word=sessions_word
            )
        )

        avg = stats.get("avg_per_day", 0)
        self._labels["total_sessions"]["value"].config(text=str(total))
        self._labels["total_sessions"]["sub"].config(text=tr("stats_avg_per_day", avg=avg))

        secs = stats.get("longest_session_seconds", 0) or 0
        h = secs // 3600
        m = (secs % 3600) // 60
        s = secs % 60
        duration_str = f"{h:02d}:{m:02d}:{s:02d}"

        self._labels["last_session"]["value"].config(text=duration_str)
        self._labels["last_session"]["sub"].config(text=stats.get("longest_session_date", "—"))

        fav_raw = stats.get("fav_mode", "—")
        key = MODE_TRANSLATION_KEYS.get(fav_raw)
        fav_val = tr(key) if key else fav_raw

        pct = stats.get("fav_mode_percent", 0)
        self._labels["fav_mode"]["value"].config(text=fav_val)
        self._labels["fav_mode"]["sub"].config(text=tr("stats_fav_mode_pct", pct=pct))

        min_p = stats.get("min_ping")
        max_p = stats.get("max_ping")
        v1, v2 = self._labels["current_strategy"]["value"]
        v1.config(text=str(min_p) if min_p is not None else "—")
        v2.config(text=str(max_p) if max_p is not None else "—")
        self._labels["current_strategy"]["sub"].config(text=tr("stats_ping_minmax"))

    def destroy(self):
        self._destroyed = True
        self._cancel_retry_timer()
        super().destroy()

    def _on_install_id_click(self, event=None):
        if not messagebox.askyesno(
            tr("error_warning"),
            tr("stats_install_id_warning_message")
        ):
            return
        self._show_install_id()

    def _show_install_id(self):
        try:
            iid = getattr(self.app, "user_stats", None)
            iid = iid.install_id if iid else None
        except Exception:
            iid = None

        if not iid:
            messagebox.showerror(tr("error"), tr("stats_install_id_not_available"))
            return

        try:
            self.app.root.clipboard_clear()
            self.app.root.clipboard_append(iid)
            self.app.root.update()
            copied = True
        except Exception:
            copied = False

        body = iid
        if copied:
            body += "\n\n" + tr("notification_install_id_copied")

        messagebox.showinfo(tr("information_desc"), body)